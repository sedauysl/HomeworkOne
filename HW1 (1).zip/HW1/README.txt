Open hw-01.Rproj file in RStudio by double clicking.
In RStudio, open hw-01.Rmd file and modify its contents.